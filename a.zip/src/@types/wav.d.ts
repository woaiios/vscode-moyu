declare module '*.wav' {
  const url: string
  export default url
}
